

public class RunSquare {

	public static void main(String[] Args){
		Square frame = new Square();
	}
}
