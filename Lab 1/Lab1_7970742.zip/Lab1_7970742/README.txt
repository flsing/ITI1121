Student name: Felix Singerman
Student number: 7970742
Course code: ITI1121
Lab section: A-4

This archive contains the 5 files of the lab 1, that is, this file (README.txt), the file Command.java in the directory Q1 and versions of the file ArrayTool.java correpsonding to questions 2 to 4 in directories Q2, Q3 and Q4.