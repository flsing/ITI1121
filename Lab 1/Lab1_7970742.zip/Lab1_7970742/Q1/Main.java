
/**
 * Write a description of class Main here.
 * 
 * @author Felix Singerman 
 * @version 1.0
 */
public class Main {
    public static void Lab1_7970742(String[] args) {
        System.out.println("Start of the program");
        
        for(int i=0; i < args.length; i++){ 
            
            System.out.println("Argument " + i + "is " + args[i]);
            
        }
        System.out.println("End of the program");
    }
}
